from pymidjourney.main import Midjourney
from pymidjourney.irequest import APIRequest
